# NexSci SMP — Oracle Cloud Bridge Setup Guide  v10.0

## Target Environment
- **Provider:** Oracle Cloud Free Tier
- **Instance:** ARM Ampere A1 (4 OCPU / 24 GB RAM free tier)
- **OS:** Ubuntu 22.04 LTS
- **Stack:** Java 21 · Node.js 20 LTS · PaperMC

---

## 1 — Connect to Your Instance

```bash
ssh -i ~/.ssh/your-key.pem ubuntu@<YOUR_ORACLE_IP>
```

---

## 2 — System Updates

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl wget git screen unzip net-tools
```

---

## 3 — Install Java 21 (required for PaperMC 1.21+)

```bash
sudo apt install -y openjdk-21-jre-headless
java -version   # should show 21.x
```

---

## 4 — Install Node.js 20 LTS

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
node -v    # should show v20.x
npm -v
```

---

## 5 — Oracle Firewall Rules

In the Oracle Cloud console go to:
**Networking → Virtual Cloud Networks → Security Lists → Inbound Rules**

Add the following ingress rules:

| Protocol | Port  | Source      | Purpose               |
|----------|-------|-------------|----------------------|
| TCP      | 25565 | 0.0.0.0/0   | Minecraft Java       |
| TCP      | 4000  | 0.0.0.0/0   | NexSci Bridge API    |
| TCP      | 22    | your IP     | SSH                  |

Also open the OS firewall:

```bash
sudo iptables -I INPUT -p tcp --dport 25565 -j ACCEPT
sudo iptables -I INPUT -p tcp --dport 4000   -j ACCEPT
sudo netfilter-persistent save
```

---

## 6 — Directory Structure

```
/home/ubuntu/
├── minecraft/                  ← Minecraft server
│   ├── paper.jar
│   ├── server.properties
│   ├── eula.txt
│   └── logs/
│       └── latest.log
├── nexsci/                     ← This repo
│   ├── start.sh
│   ├── stop.sh
│   ├── restart.sh
│   └── bridge/
│       ├── server.js
│       ├── .env                ← copy from .env.example, fill in secrets
│       └── ...
└── .mc.pid                     ← Auto-created by start.sh
```

---

## 7 — PaperMC Setup

```bash
mkdir -p /home/ubuntu/minecraft && cd /home/ubuntu/minecraft

# Download latest PaperMC (replace BUILD with the latest build number from papermc.io)
wget "https://api.papermc.io/v2/projects/paper/versions/1.21.1/builds/BUILD/downloads/paper-1.21.1-BUILD.jar" -O paper.jar

# Accept EULA
echo "eula=true" > eula.txt
```

Edit `server.properties` and set:
```
enable-rcon=true
rcon.port=25575
rcon.password=CHANGEME_STRONG_PASSWORD
online-mode=true
max-players=20
```

---

## 8 — Install the Bridge

```bash
cd /home/ubuntu/nexsci
git clone <your-repo-url> .    # or copy files manually

cd bridge
npm install

# Configure
cp .env.example .env
nano .env   # fill in all values
```

Make scripts executable:

```bash
chmod +x /home/ubuntu/nexsci/start.sh
chmod +x /home/ubuntu/nexsci/stop.sh
chmod +x /home/ubuntu/nexsci/restart.sh
```

---

## 9 — Firebase Service Account

1. In Firebase Console → Project Settings → Service Accounts → Generate new private key
2. Download the JSON file to your local machine
3. On your server, encode it:
   ```bash
   base64 -w0 serviceAccount.json
   ```
4. Paste the output into `.env` as `FIREBASE_SA_BASE64=`

---

## 10 — Run the Bridge

**Manual test:**
```bash
cd /home/ubuntu/nexsci/bridge
node server.js
```

**Production (auto-restart via systemd):**

```bash
sudo nano /etc/systemd/system/nexsci-bridge.service
```

```ini
[Unit]
Description=NexSci SMP Bridge
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/nexsci/bridge
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=5
EnvironmentFile=/home/ubuntu/nexsci/bridge/.env

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable nexsci-bridge
sudo systemctl start nexsci-bridge
sudo systemctl status nexsci-bridge
```

---

## 11 — Website Configuration

In the NexSci SMP web app:
1. Log in as admin
2. Open **Server Status** panel → Edit
3. Set **Bridge URL** to `https://your-oracle-ip:4000`
   (or use a domain + nginx reverse proxy for HTTPS)

The bridge badge will turn green within 15 seconds of the daemon starting.

---

## 12 — Optional: nginx Reverse Proxy (HTTPS)

```bash
sudo apt install -y nginx certbot python3-certbot-nginx

sudo nano /etc/nginx/sites-available/nexsci-bridge
```

```nginx
server {
    listen 443 ssl;
    server_name bridge.yourdomain.com;

    location / {
        proxy_pass http://127.0.0.1:4000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

```bash
sudo certbot --nginx -d bridge.yourdomain.com
sudo systemctl reload nginx
```

Then set Bridge URL to `https://bridge.yourdomain.com` in the web app.
